/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class testerkalkulator {
    public static void main(String[] args){
        
        double Penambahan;
        double Pengurangan;
        double Perkalian;
        double Pembagian;
        
        
        kalkulator kalkulator = new kalkulator();
        Penambahan = kalkulator.getPenambahan(20,2);
        Pengurangan = kalkulator.getPengurangan(10.2,2);
        Perkalian = kalkulator.getPerkalian(20,10);
        Pembagian = kalkulator.getPembagian(11,2);
        
        System.out.println("Hasil penambahan adalah "+Penambahan);
        System.out.println("Hasil pengurangan adalah "+Pengurangan);
        System.out.println("Hasil perkalian adalah "+Perkalian);
        System.out.println("Hasil pembagian adalah "+Pembagian);
        
        
    }
    
}
