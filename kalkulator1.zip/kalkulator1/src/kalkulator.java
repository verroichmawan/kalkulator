/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class kalkulator {
    public static double getPenambahan(double nilai1, double nilai2){
        double hasil = nilai1 + nilai2;
        return hasil;
    }
    
    public static double getPengurangan(double nilai1, double nilai2){
        double hasil = nilai1 - nilai2;
        return hasil;
    }
    
    public static double getPerkalian(double nilai1, double nilai2){
        double hasil = nilai1 * nilai2;
        return hasil;
    }
    
    public static double getPembagian(double nilai1, double nilai2){
        double hasil = nilai1 / nilai2;
        return hasil;
    }
}
